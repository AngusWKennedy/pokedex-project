export default {
  plugins: {
    tailwindcss: {},
  },
}
