import React from 'react'
import {Link, Outlet} from "react-router-dom"

export default function Layout() {
  return (
    <>
        <header className='bg-red-600 p-4 w-full text-white gap-10 flex items-center'>
            <Link to="/">Pokédex</Link>
            <Link to="/search">Advanced Search</Link>
            <Link to="/quiz">Quiz</Link>
        </header>
        <div>
            <Outlet />
        </div>
    </>
  )
}
