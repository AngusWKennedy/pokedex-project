import React, {createContext, useContext, useState} from 'react'
import PokeDatabase from './data/Pokemon.csv?raw'

export default function QuizPage() {

    var answer = 0
    var stats = []
    var entries = ""
    var correctName = ""
    const [answerResult, setAnsResult] = useState("")
    const [rights, setRights] = useState(0)
    const [wrongs, setWrongs] = useState(0)

    function SetRandomNumber()
    {
        answer = Math.ceil(Math.random() * 800)
        entries = PokeDatabase.split("\n");
        stats = entries[answer].split(",");
    }

    SetRandomNumber()
    console.log(answer)

    function ShowRightAndWrongAnswers()
    {
        return (
            <div className="grid grid-cols-2 mx-48">
                <div className="grid gap-4 mt-2 mx-2 bg-lime-500 text-white text-xl font-bold rounded-xl px-5 py-5">
                Correct: {rights}
                </div>
                <div className="grid gap-4 mt-2 mx-2 bg-red-500 text-white text-xl font-bold rounded-xl px-5 py-5">
                Incorrect: {wrongs}
                </div>
            </div>
        )
    }

    function ShowGeneration()
    {
        return (
            <div className="grid gap-4 mt-2 bg-blue-500 text-white text-xl font-bold rounded-xl px-5 py-5">
            This Pokémon is from Generation {stats[11]}.
            </div>
        )
    }

    function ShowTypes()
    {
        if (stats[3] != "")
        {
            return (
                <div className="grid gap-4 mt-2 bg-blue-500 text-white text-xl font-bold rounded-xl px-5 py-5">
                This Pokémon's types are {stats[2]} and {stats[3]}.
                </div>
            )
        }
        else
        {
            return (
                <div className="grid gap-4 mt-2 bg-blue-500 text-white text-xl font-bold rounded-xl px-5 py-5">
                This Pokémon's type is {stats[2]}.
                </div>
            )
        }

    }

    function ShowBST()
    {
        return (
            <div className="grid gap-4 mt-2 bg-blue-500 text-white text-xl font-bold rounded-xl px-5 py-5">
            This Pokémon's Base Stat total is {stats[4]}.
            </div>
        )
    }

    function ShowFirstLetter()
    {
        return (
            <div className="grid gap-4 mt-2 bg-blue-500 text-white text-xl font-bold rounded-xl px-5 py-5">
            This Pokémon begins with the letter "{stats[1][0]}".
            </div>
        )
    }

    function AnswerArea()
    {
        return (
            <div className="grid gap-4 mt-2 bg-blue-500 text-white text-xl font-bold rounded-xl px-5 py-5">
            Who's that Pokémon?
            <SearchBar />
            {answerResult}
            </div>
        )
    }

    function SearchBar()
    {
        const [searchInput, setSearchInput] = useState("")

        const handleSubmit = (event) => {
            event.preventDefault();
            JudgeAnswer(searchInput)
          }

        return (
            <form onSubmit={handleSubmit}>
                <input type="text" className="bg-gray-300 text-black font-bold rounded-2xl px-5 py-2 text-lg w-full" placeholder = "Type your answer here. Press Enter to submit." value={searchInput} onChange={(e) => setSearchInput(e.target.value)}/>
            </form>
        )
    }

    function JudgeAnswer(s)
    {
        correctName = stats[1].toUpperCase().split(" (")[0];
        if (s.toUpperCase() == correctName)
        {
            setAnsResult(stats[1] + " was correct! Well done!")
            setRights(rights + 1)
        }
        else
        {
            setAnsResult("Wrong... The answer was " + stats[1] + ".")
            setWrongs(wrongs + 1)
        }
    }

    function ShowInstructions()
    {
        return (
            <>
                <div className="text-black font-bold text-4xl">
                Who's that Pokémon?
                </div>
                <div className="text-black font-semibold text-xl">
                Use the information provided to guess the Pokémon. How many can you answer correctly?
                </div>
            </>
        )
    }

  return (
    <div>
        <div className='bg-blue-200 rounded-xl px-5 py-5 mt-3'>
        <ShowInstructions />
        </div>
        <div className='bg-blue-200 rounded-xl px-5 py-5 mt-3'>
        <ShowRightAndWrongAnswers />
        <ShowGeneration />
        <ShowTypes />
        <ShowBST />
        <ShowFirstLetter />
        <AnswerArea />
        </div>
    </div>
  )
}
