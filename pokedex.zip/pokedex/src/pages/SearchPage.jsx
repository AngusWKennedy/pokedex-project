import React, {createContext, useContext, useState} from 'react'
import PokeDatabase from './data/Pokemon.csv?raw'

export default function SearchPage() {

  var stats = []
  var entries = ""
  var matchesCriteria = true
  var inStatRange = false

  var rows = [];

  const [searchByGen, setSearchByGen] = React.useState(false);
  const [generation, setGen] = React.useState("1");
  const [searchByType, setSearchByType] = React.useState(false);
  const [type, setType] = React.useState("Normal");
  const [searchByStat, setSearchByStat] = React.useState(false);
  const [statKind, setStatKind] = React.useState("5");
  const [statMin, setStatMin] = React.useState(50);
  const [statMax, setStatMax] = React.useState(150);

  function Pokemon(name) {
    return (
        <div className = "bg-red-600 font-bold text-white rounded-lg mx-1 my-1 py-2">{name}</div>
      )
  }

  function SearchResults()
    {
      rows = []

        for (let i = 1; i < 801; i++)
        {
            entries = PokeDatabase.split("\n");
            stats = entries[i].split(",");

            matchesCriteria = true
            if (stats[11] != generation && searchByGen)
            {
              matchesCriteria = false
            }
            if (searchByType && !(stats[2] == type || stats[3] == type))
            {
              matchesCriteria = false
            }
            inStatRange = (stats[statKind]) * 1 >= statMin && (stats[statKind]) * 1 <= statMax
            if (searchByStat && !(inStatRange))
            {
              matchesCriteria = false
              console.log(stats[statKind])
            }

            if (matchesCriteria)
            {
              rows.push(Pokemon(stats[1]));
            }
        }

        return (
          <div className="grid grid-cols-4">{rows}</div>
        )
    }

  function InputParams() {
    return (
      <div> 
        <GenerationSection />
        <TypeSection />
        <StatSection />
      </div>
    )
  }

  function GenerationSection() {
    if (searchByGen)
    {
      return (
        <div className="grid grid-cols-1 bg-orange-300 font-bold rounded-lg my-3 py-3"> 
          <GenerationCheckbox />
          <GenerationSelector />
        </div>
      )
    }
    else
    {
      return (
        <div className="grid grid-cols-1 bg-gray-300 font-bold rounded-lg my-3 py-3"> 
          <GenerationCheckbox />
        </div>
      )
    }
  }

  function GenerationSelector() {

    const handleChange = (event) => {

      setGen(event.target.value);
   
    };

    return (
      <div>
        <select value={generation} onChange={handleChange} className="font-bold rounded-lg">

        <option value="1">Generation 1</option>
        <option value="2">Generation 2</option>
        <option value="3">Generation 3</option>
        <option value="4">Generation 4</option>
        <option value="5">Generation 5</option>
        <option value="6">Generation 6</option>

        </select>
      </div>
    )
  }

  function GenerationCheckbox () {

    const toggleGenerationSearch = (event) => {
      setSearchByGen(event.target.checked)
    }

    return (
      <div>
        Search by Generation
        <input type="checkbox" checked={searchByGen} onChange={toggleGenerationSearch} />
      </div>
    )
  }

  function TypeSection() {
    if (searchByType)
    {
      return (
        <div className="grid grid-cols-1 bg-orange-300 font-bold rounded-lg my-3 py-3"> 
          <TypeCheckbox />
          <TypeSelector />
        </div>
      )
    }
    else
    {
      return (
        <div className="grid grid-cols-1 bg-gray-300 font-bold rounded-lg my-3 py-3"> 
          <TypeCheckbox />
        </div>
      )
    }
  }

  function TypeSelector() {

    const handleChange = (event) => {

      setType(event.target.value);
   
    };

    return (
      <div>
        <select value={type} onChange={handleChange} className="font-bold rounded-lg">

        <option value="Bug">Bug</option>
        <option value="Dark">Dark</option>
        <option value="Dragon">Dragon</option>
        <option value="Electric">Electric</option>
        <option value="Fairy">Fairy</option>
        <option value="Fighting">Fighting</option>
        <option value="Fire">Fire</option>
        <option value="Flying">Flying</option>
        <option value="Ghost">Ghost</option>
        <option value="Grass">Grass</option>
        <option value="Ground">Ground</option>
        <option value="Ice">Ice</option>
        <option value="Normal">Normal</option>
        <option value="Poison">Poison</option>
        <option value="Psychic">Psychic</option>
        <option value="Rock">Rock</option>
        <option value="Steel">Steel</option>
        <option value="Water">Water</option>

        </select>
      </div>
    )
  }

  function TypeCheckbox () {

    const toggleTypeSearch = (event) => {
      setSearchByType(event.target.checked)
    }

    return (
      <div>
        Search by Type
        <input type="checkbox" checked={searchByType} onChange={toggleTypeSearch} />
      </div>
    )
  }

  function StatSection() {
    if (searchByStat)
    {
      return (
        <div className="grid grid-cols-1 bg-orange-300 font-bold rounded-lg my-3 py-3"> 
          <StatCheckbox />
          <StatSelector />
        </div>
      )
    }
    else
    {
      return (
        <div className="grid grid-cols-1 bg-gray-300 font-bold rounded-lg my-3 py-3"> 
          <StatCheckbox />
        </div>
      )
    }
  }

  function StatSelector() {

    const changeStatKind = (event) => {

      setStatKind(event.target.value);
   
    };

    const changeStatMin = (event) => {

      setStatMin(event.target.value);
   
    };

    const changeStatMax = (event) => {

      setStatMax(event.target.value);
   
    };

    return (
      <div>
        <select value={statKind} onChange={changeStatKind} className="font-bold rounded-lg">

        <option value="5">HP</option>
        <option value="6">Attack</option>
        <option value="7">Defense</option>
        <option value="8">Special Attack</option>
        <option value="9">Special Defense</option>
        <option value="10">Speed</option>
        <option value="4">Base Stat Total</option>
        </select>

        is between

        <input type="number" value={statMin} onChange={changeStatMin}></input>
        and
        <input type="number"value={statMax} onChange={changeStatMax}></input>
      </div>
    )
  }

  function StatCheckbox () {

    const toggleStatSearch = (event) => {
      setSearchByStat(event.target.checked)
    }

    return (
      <div>
        Search by Stat
        <input type="checkbox" checked={searchByStat} onChange={toggleStatSearch} />
      </div>
    )
  }

  return (
    <div>
      <InputParams />
      <SearchResults />
    </div>
  )
}
