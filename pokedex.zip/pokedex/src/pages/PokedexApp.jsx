import React, {createContext, useContext, useState} from 'react'
import PokeDatabase from './data/Pokemon.csv?raw'


export default function PokedexApp() {

    const [entry, setEntry] = useState("")
    const [counter, setCounter] = useState(1)
    const [searchError, setSearchError] = useState("")
    var stats = []
    var entries = ""
    var pokemonType = ""
    var toCompare = ""

    function changeCounter(value)
    {
        setCounter(counter + value)
        if (counter == 1 && value == -1)
        {
            setCounter(800)
        }
        if (counter == 800 && value == 1)
        {
            setCounter(1)
        }
    }

    function SetEntry()
    {
        //console.log(PokeDatabase)
        entries = PokeDatabase.split("\n");
        stats = entries[counter].split(",");
    }

    function ShowNumberAndName() {
        if (stats[12] == "True")
        {
            return (
                <div className="grid gap-4 mt-2 bg-amber-500 text-white text-3xl font-bold rounded-xl px-1 py-7">
                #{stats[0]}: {stats[1]}
                </div>
            )
        }
        else
        {
            return (
                <div className="grid gap-4 mt-2 bg-gray-500 text-white text-3xl font-bold rounded-xl px-1 py-7">
                #{stats[0]}: {stats[1]}
                </div>
            )
        }

    }

    function SetType1() {
        pokemonType = stats[2]
    }

    function SetType2() {
        pokemonType = stats[3]
    }

    function ShowBothTypes() {
        return (
            <div className="grid grid-cols-2 gap-4 mt-2 bg-gray-500 text-white font-bold rounded-2xl px-5 py-5">
            <SetType1 />
            <ShowType />
            <SetType2 />
            <ShowType />
            </div>
        )
    }

    function ShowType() {
        switch (pokemonType)
        {
            case "Bug":
                return (<span className="bg-lime-500 text-white font-bold text-xl rounded-2xl px-5 py-3">Bug</span>)
            case "Dark":
                return (<span className="bg-blue-900 text-white font-bold text-xl rounded-2xl px-5 py-3">Dark</span>)
            case "Dragon":
                return (<span className="bg-teal-600 text-white font-bold text-xl rounded-2xl px-5 py-3">Dragon</span>)
            case "Electric":
                return (<span className="bg-yellow-400 text-white font-bold text-xl rounded-2xl px-5 py-3">Electric</span>)
            case "Fairy":
                return (<span className="bg-pink-300 text-white font-bold text-xl rounded-2xl px-5 py-3">Fairy</span>)
            case "Fighting":
                return (<span className="bg-red-600 text-white font-bold text-xl rounded-2xl px-5 py-3">Fighting</span>)
            case "Fire":
                return (<span className="bg-orange-500 text-white font-bold text-xl rounded-2xl px-5 py-3">Fire</span>)
            case "Flying":
                return (<span className="bg-sky-400 text-white font-bold text-xl rounded-2xl px-5 py-3">Flying</span>)
            case "Ghost":
                return (<span className="bg-purple-400 text-white font-bold text-xl rounded-2xl px-5 py-3">Ghost</span>)
            case "Grass":
                return (<span className="bg-green-600 text-white font-bold text-xl rounded-2xl px-5 py-3">Grass</span>)
            case "Ground":
                return (<span className="bg-yellow-700 text-white font-bold text-xl rounded-2xl px-5 py-3">Ground</span>)
            case "Ice":
                return (<span className="bg-cyan-300 text-white font-bold text-xl rounded-2xl px-5 py-3">Ice</span>)
            case "Normal":
                return (<span className="bg-stone-400 text-white font-bold text-xl rounded-2xl px-5 py-3">Normal</span>)
            case "Poison":
                return (<span className="bg-purple-700 text-white font-bold text-xl rounded-2xl px-5 py-3">Poison</span>)
            case "Psychic":
                return (<span className="bg-pink-600 text-white font-bold text-xl rounded-2xl px-5 py-3">Psychic</span>)
            case "Rock":
                return (<span className="bg-amber-900 text-white font-bold text-xl rounded-2xl px-5 py-3">Rock</span>)
            case "Steel":
                return (<span className="bg-gray-600 text-white font-bold text-xl rounded-2xl px-5 py-3">Steel</span>)
            case "Water":
                return (<span className="bg-blue-600 text-white font-bold text-xl rounded-2xl px-5 py-3">Water</span>)
        
            default:
                return (<span className="bg-gray-500 text-white font-bold text-xl rounded-2xl px-5 py-3"></span>)
        }
    }

    function NavigationButtons() {
        return (
            <div className="grid grid-cols-2 gap-4 py-2">
                <button className="bg-blue-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => changeCounter(-1)}>← Previous</button>
                <button className="bg-blue-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => changeCounter(1)}>Next →</button>
            </div>
        )
    }

    function ShowBaseStats()
    {
        return (
            <div className="grid gap-1 bg-gray-500 text-white font-bold rounded-2xl px-10 py-5">
            Base Stats:
                <div className="bg-red-300 text-black font-bold rounded-2xl px-5 py-2 text-lg">HP: {stats[5]}</div>
                <div className="bg-orange-300 text-black font-bold rounded-2xl px-5 py-2 text-lg">Attack: {stats[6]}</div>
                <div className="bg-yellow-200 text-black font-bold rounded-2xl px-5 py-2 text-lg">Defense: {stats[7]}</div>
                <div className="bg-blue-300 text-black font-bold rounded-2xl px-5 py-2 text-lg">Special Attack: {stats[8]}</div>
                <div className="bg-lime-300 text-black font-bold rounded-2xl px-5 py-2 text-lg">Special Defense: {stats[9]}</div>
                <div className="bg-pink-300 text-black font-bold rounded-2xl px-5 py-2 text-lg">Speed: {stats[10]}</div>
                <div className="bg-gray-300 text-black font-bold rounded-2xl px-5 py-2 text-lg">Total: {stats[4]}</div>
            </div>
        )
    }

    function SearchBar()
    {
        const [searchInput, setSearchInput] = useState("")

        const handleSubmit = (event) => {
            event.preventDefault();
            SearchForPokemon(searchInput)
          }

        return (
            <form onSubmit={handleSubmit}>
                <input type="text" className="bg-gray-300 font-bold rounded-2xl px-5 py-2 text-lg w-full" placeholder = "Search for a Pokémon by name or ID number." value={searchInput} onChange={(e) => setSearchInput(e.target.value)}/>
            </form>
        )
    }

    function SearchForPokemon(s)
    {
        setSearchError("")
        console.log(s)
        if (isNaN(+s))
        {
            console.log("Search is not a number.")
            SearchByName(s)
        }
        else
        {
            console.log("Search is a number")
            SearchByNumber(+s)
        }
    }

    function SearchByNumber(num)
    {
        for (let i = 1; i < 801; i++)
        {
            entries = PokeDatabase.split("\n");
            stats = entries[i].split(",");
            if (stats[0] == num)
            {
                setCounter(i)
                i = 999
            }
            if (i == 800)
            {
                console.log("Reached end of list.")
                setSearchError("No Pokémon with the ID Number of " + num + " was found.")
            }
        }
    }

    function SearchByName(name)
    {
        for (let i = 1; i < 801; i++)
        {
            entries = PokeDatabase.split("\n");
            stats = entries[i].split(",");
            toCompare = stats[1].toUpperCase().split(" (")[0];
            if (toCompare == name.toUpperCase())
            {
                setCounter(i)
                i = 999
            }
            if (i == 800)
            {
                console.log("Reached end of list.")
                setSearchError("No Pokémon named \"" + name + "\" was found.")
            }
        }
    }

    function ShowSearchError()
    {
        return (
            <div className='bg-red-200 mt-3 font-bold'>
                {searchError}
            </div>
        )
    }

    function GenerationButtons()
    {
        return (
            <div className="grid grid-cols-7 gap-4 pt-2">
                <button className="bg-violet-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => setCounter(1)}>Generation 1</button>
                <button className="bg-violet-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => setCounter(167)}>Generation 2</button>
                <button className="bg-violet-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => setCounter(273)}>Generation 3</button>
                <button className="bg-violet-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => setCounter(433)}>Generation 4</button>
                <button className="bg-violet-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => setCounter(554)}>Generation 5</button>
                <button className="bg-violet-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => setCounter(719)}>Generation 6</button>
                <button className="bg-rose-500 text-white font-bold px-2 py-3 rounded-2xl text-lg" onClick={() => setCounter(Math.ceil(Math.random() * 800))}>Random Pokémon</button>
            </div>
        )
    }


    return (
      <div>
        <SetEntry />
        <GenerationButtons />
        <NavigationButtons />
        <SearchBar />
        <ShowSearchError />
        <div className="grid grid-cols-2 gap-4 py-2">
            <ShowNumberAndName />
            <ShowBothTypes />
        </div>
        <ShowBaseStats />
      </div>
    )
}
