import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import PokedexApp from './pages/PokedexApp'
import SearchPage from './pages/SearchPage'
import QuizPage from './pages/QuizPage'
import Layout from './components/Layout'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path = "/" element = {<Layout />}>
          <Route index element = {<PokedexApp />}></Route>
          <Route path = "/search" element = {<SearchPage />}></Route>
          <Route path = "/quiz" element = {<QuizPage />}></Route>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
